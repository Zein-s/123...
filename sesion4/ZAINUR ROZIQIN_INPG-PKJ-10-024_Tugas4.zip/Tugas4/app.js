// Deklarasi dan inisialisasi variabel
const diameter = 14;
const jariJari = diameter / 2;
const phi = 3.14159;

// Menghitung luas lingkaran
const luas = phi * jariJari * jariJari;

// Menghitung keliling lingkaran
const keliling = 2 * phi * jariJari;

// Menampilkan hasil
console.log("Luas Lingkaran: " + luas);
console.log("Keliling Lingkaran: " + keliling);
